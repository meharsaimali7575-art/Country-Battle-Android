#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VERSION="${NODE_MOBILE_VERSION:-18.20.4}"
API="https://api.github.com/repos/nodejs-mobile/nodejs-mobile/releases/tags/v${VERSION}"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
command -v curl >/dev/null || { echo 'curl is required' >&2; exit 1; }
command -v unzip >/dev/null || { echo 'unzip is required' >&2; exit 1; }
command -v jq >/dev/null || { echo 'jq is required' >&2; exit 1; }
echo "Fetching official Node.js Mobile v${VERSION} release metadata..."
curl --fail --location --retry 3 --retry-delay 2 "$API" -o "$TMP/release.json"
# Select the Android archive from the official release. The API asset name is
# intentionally discovered rather than guessed, so upstream naming changes fail clearly.
ASSET_URL="$(jq -r '[.assets[] | select((.name|ascii_downcase|contains("android")) and (.name|ascii_downcase|endswith(".zip")))] | first | .browser_download_url // empty' "$TMP/release.json")"
ASSET_NAME="$(jq -r '[.assets[] | select((.name|ascii_downcase|contains("android")) and (.name|ascii_downcase|endswith(".zip")))] | first | .name // empty' "$TMP/release.json")"
if [[ -z "$ASSET_URL" ]]; then
  echo "No Android ZIP asset found in official release v${VERSION}. Assets were:" >&2
  jq -r '.assets[].name' "$TMP/release.json" >&2
  exit 2
fi
echo "Downloading official asset: $ASSET_NAME"
curl --fail --location --retry 3 --retry-delay 2 "$ASSET_URL" -o "$TMP/node-mobile.zip"
unzip -q "$TMP/node-mobile.zip" -d "$TMP/unpacked"
# The Android archive contains several ABIs. Do not use the first libnode.so:
# find order can return x86_64, which cannot be packaged as arm64-v8a.
LIB=""
while IFS= read -r candidate; do
  if readelf -h "$candidate" 2>/dev/null | grep -qE 'Machine:.*AArch64'; then
    LIB="$candidate"
    break
  fi
done < <(find "$TMP/unpacked" -type f -name libnode.so -print)
HEADER="$(find "$TMP/unpacked" -type f -path '*/include/node/node.h' -print -quit)"
if [[ -z "$LIB" || -z "$HEADER" ]]; then
  echo 'Could not find an AArch64 libnode.so and include/node/node.h in the Android release archive.' >&2
  echo 'Available libnode.so files and detected architectures:' >&2
  while IFS= read -r candidate; do
    echo "--- $candidate" >&2
    readelf -h "$candidate" 2>/dev/null | grep 'Machine:' >&2 || true
  done < <(find "$TMP/unpacked" -type f -name libnode.so -print)
  exit 3
fi
echo "Selected ARM64 Node.js Mobile library: $LIB"
DEST="$ROOT/app/libnode"
mkdir -p "$DEST/bin/arm64-v8a" "$DEST/include/node"
cp "$LIB" "$DEST/bin/arm64-v8a/libnode.so"
HEADER_ROOT="$(dirname "$HEADER")"
cp -a "$HEADER_ROOT"/. "$DEST/include/node/"
# libnode from this distribution is linked against the Android shared libc++.
# Copy the exact NDK runtime used for this build into the APK's jniLibs directory.
if [[ -n "${ANDROID_NDK_HOME:-}" ]]; then
  CXX="$(find "$ANDROID_NDK_HOME/toolchains/llvm/prebuilt" -path '*/sysroot/usr/lib/aarch64-linux-android/libc++_shared.so' -print -quit)"
  if [[ -n "$CXX" ]]; then cp "$CXX" "$DEST/bin/arm64-v8a/libc++_shared.so"; fi
fi
test -s "$DEST/bin/arm64-v8a/libnode.so"
test -s "$DEST/include/node/node.h"
echo "Node.js Mobile v${VERSION} ARM64 runtime and headers installed."
