'use strict';
const path = require('node:path');
const fs = require('node:fs');
const projectDir = __dirname;
process.chdir(projectDir);
process.env.HOST = '127.0.0.1';
process.env.PORT = '8787';
const envFile = path.join(projectDir, '.env');
if (!fs.existsSync(envFile)) {
  const example = path.join(projectDir, '.env.example');
  if (fs.existsSync(example)) fs.copyFileSync(example, envFile);
}
require(path.join(projectDir, 'server.js'));
