"use strict";
const express = require("express");
const { google } = require("googleapis");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
require("dotenv").config({ path: path.join(__dirname, ".env") });

const app = express();
const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || "127.0.0.1";
const CLIENT_ID = process.env.GOOGLE_CLIENT_ID || "";
const CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET || "";
const REDIRECT_URI = process.env.GOOGLE_REDIRECT_URI || `http://localhost:${PORT}/auth/callback`;
const TOKEN_PATH = path.join(__dirname, "token.json");
const SCOPES = ["https://www.googleapis.com/auth/youtube.readonly"];
const clients = new Set();
const seenMessageIds = new Set();
const oauthStates = new Map();
let pollTimer = null;
let reconnectTimer = null;
let polling = false;
let generation = 0;
let connectRequested = false;
let liveChatId = null;
let nextPageToken = null;
let pollEveryMs = 5000;
let firstPollCutoff = 0;
let lastBroadcastTitle = "";
let lastSuccessAt = null;
let state = "DISCONNECTED";
let lastError = "Not connected. Authorize YouTube, start a live stream with chat, then connect.";
let youtube = null;

const oauth2 = new google.auth.OAuth2(CLIENT_ID || undefined, CLIENT_SECRET || undefined, REDIRECT_URI);
function readTokenFile() {
  try { return JSON.parse(fs.readFileSync(TOKEN_PATH, "utf8")); } catch { return null; }
}
const savedToken = readTokenFile();
if (savedToken) oauth2.setCredentials(savedToken);
function saveTokens(tokens) {
  const previous = readTokenFile() || {};
  const merged = { ...previous, ...tokens };
  const temp = TOKEN_PATH + ".tmp";
  fs.writeFileSync(temp, JSON.stringify(merged, null, 2), { mode: 0o600 });
  try { fs.chmodSync(temp, 0o600); } catch {}
  fs.renameSync(temp, TOKEN_PATH);
}
oauth2.on("tokens", tokens => { try { saveTokens(tokens); } catch (e) { console.error("Could not securely save refreshed OAuth token:", e.message); } });

function isAuthenticated() { return Boolean(oauth2.credentials && (oauth2.credentials.refresh_token || oauth2.credentials.access_token)); }
function statusPayload() {
  return { type: "status", state, authenticated: isAuthenticated(), connected: state === "CONNECTED", liveChatId: liveChatId || null, broadcastTitle: lastBroadcastTitle || null, viewers: clients.size, lastSuccessAt, error: lastError || null };
}
function publish(payload) {
  const line = `data: ${JSON.stringify(payload)}\n\n`;
  for (const res of clients) { try { res.write(line); } catch { clients.delete(res); } }
}
function setState(next, error = null) {
  state = next;
  lastError = error;
  publish(statusPayload());
  console.log(`[${new Date().toLocaleTimeString()}] ${next}${error ? `: ${error}` : ""}`);
}
function getApiError(e) {
  const data = e?.response?.data;
  const apiError = data?.error;
  const first = apiError?.errors?.[0];
  return { code: Number(e?.code || e?.response?.status || apiError?.code || 0), reason: first?.reason || apiError?.status || "", message: data?.error?.message || e?.message || "Unknown YouTube API error" };
}
function isReauthError(info) { return info.code === 401 || /invalid_grant|invalid credentials|token has been expired or revoked/i.test(info.message); }
function isChatEnded(info) { return info.code === 404 || /liveChatEnded|liveChatNotFound|liveChatDisabled|forbidden/i.test(info.reason + " " + info.message); }
function clearTimers() {
  if (pollTimer) clearTimeout(pollTimer);
  if (reconnectTimer) clearTimeout(reconnectTimer);
  pollTimer = reconnectTimer = null;
}
function stopConnection(userInitiated = false) {
  generation++;
  clearTimers();
  connectRequested = !userInitiated && connectRequested;
  liveChatId = null;
  nextPageToken = null;
  polling = false;
  youtube = null;
  if (userInitiated) connectRequested = false;
}
function scheduleReconnect(delay = 15000) {
  if (!connectRequested || reconnectTimer) return;
  reconnectTimer = setTimeout(async () => {
    reconnectTimer = null;
    await discoverAndConnect(true);
  }, delay);
}
async function discoverAndConnect(isRetry = false) {
  if (!connectRequested) return;
  if (!CLIENT_ID || !CLIENT_SECRET) {
    setState("ERROR", "Google OAuth credentials are missing. Fill in GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in .env.");
    return;
  }
  if (!isAuthenticated()) {
    setState("ERROR", "YouTube account is not authorized. Open /auth/google and authorize the channel owner account.");
    return;
  }
  if (!isRetry) setState("CONNECTING", "Finding an active YouTube live broadcast with live chat…");
  try {
    const api = google.youtube({ version: "v3", auth: oauth2 });
   const result = await api.liveBroadcasts.list({ part: ["snippet", "status"], broadcastStatus: "active", maxResults: 10 });
    const broadcast = (result.data.items || []).find(item => item.snippet?.liveChatId);
    if (!broadcast) {
      liveChatId = null;
      setState("DISCONNECTED", "No active broadcast with live chat was found. Start your YouTube Live stream and keep chat enabled; the bridge will retry automatically.");
      scheduleReconnect(15000);
      return;
    }
    clearTimers();
    generation++;
    const myGeneration = generation;
    youtube = api;
    liveChatId = broadcast.snippet.liveChatId;
    lastBroadcastTitle = broadcast.snippet.title || "YouTube Live";
    nextPageToken = null;
    firstPollCutoff = Date.now();
    pollEveryMs = 5000;
    setState("CONNECTING", `Found live broadcast: ${lastBroadcastTitle}. Connecting to live chat…`);
    pollOnce(myGeneration);
  } catch (e) {
    const info = getApiError(e);
    if (isReauthError(info)) {
      setState("ERROR", `YouTube authorization failed: ${info.message}. Re-authorize at /auth/google.`);
      return;
    }
    setState("DISCONNECTED", `Could not find the active broadcast: ${info.message}. Retrying automatically.`);
    scheduleReconnect(15000);
  }
}
async function pollOnce(myGeneration) {
  if (!connectRequested || myGeneration !== generation || !liveChatId || !youtube || polling) return;
  polling = true;
  try {
    const args = { liveChatId, part: ["snippet", "authorDetails"], maxResults: 200 };
    if (nextPageToken) args.pageToken = nextPageToken;
    const response = await youtube.liveChatMessages.list(args);
    if (myGeneration !== generation) return;
    nextPageToken = response.data.nextPageToken || nextPageToken;
    pollEveryMs = Math.max(1000, Number(response.data.pollingIntervalMillis || 5000));
    lastSuccessAt = new Date().toISOString();
    setState("CONNECTED", null);
    const items = response.data.items || [];
    for (const item of items) {
      if (!item?.id || seenMessageIds.has(item.id)) continue;
      seenMessageIds.add(item.id);
      const snippet = item.snippet || {};
      const author = item.authorDetails || {};
      const publishedAt = snippet.publishedAt || null;
      // The first API page can contain old chat history. Only forward messages posted
      // after this bridge connection began; later pages are processed normally.
      if (publishedAt && Date.parse(publishedAt) < firstPollCutoff) continue;
      const text = snippet.textMessageDetails?.messageText || snippet.displayMessage || "";
      if (!text.trim()) continue;
      publish({ type: "chat", id: item.id, text, author: author.displayName || "YouTube viewer", authorChannelId: author.channelId || null, publishedAt });
      console.log(`Chat: ${author.displayName || "viewer"}: ${text}`);
    }
    if (seenMessageIds.size > 12000) {
      const keep = Array.from(seenMessageIds).slice(-6000);
      seenMessageIds.clear(); keep.forEach(id => seenMessageIds.add(id));
    }
    if (response.data.offlineAt) {
      liveChatId = null;
      setState("DISCONNECTED", "YouTube reports that this live chat has ended. Waiting for the next active broadcast…");
      scheduleReconnect(12000);
      return;
    }
  } catch (e) {
    if (myGeneration !== generation) return;
    const info = getApiError(e);
    if (isReauthError(info)) {
      setState("ERROR", `YouTube authorization expired or was revoked: ${info.message}. Re-authorize at /auth/google.`);
      connectRequested = false;
      return;
    }
    if (isChatEnded(info)) {
      liveChatId = null;
      nextPageToken = null;
      setState("DISCONNECTED", `Live chat is no longer available (${info.reason || info.code}). Searching for an active broadcast again…`);
      scheduleReconnect(12000);
      return;
    }
    setState("DISCONNECTED", `YouTube chat temporarily unavailable: ${info.message}. Reconnecting automatically…`);
    const delay = /rateLimitExceeded/i.test(info.reason) ? Math.max(pollEveryMs, 10000) : Math.min(Math.max(pollEveryMs, 3000) * 2, 30000);
    pollEveryMs = delay;
  } finally {
    polling = false;
    if (connectRequested && myGeneration === generation && liveChatId) {
      pollTimer = setTimeout(() => pollOnce(myGeneration), pollEveryMs);
    }
  }
}

app.disable("x-powered-by");
app.use(express.json({ limit: "16kb" }));
app.use((req, res, next) => {
  // This service binds to loopback only. Wildcard CORS is needed for the local file:// game page.
  res.setHeader("Access-Control-Allow-Origin", process.env.ALLOWED_ORIGIN || "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  res.setHeader("Cache-Control", "no-store");
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});
app.get("/", (_req, res) => res.type("html").send(`<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Country Battle YouTube Bridge</title><style>body{font:16px system-ui;background:#101827;color:#eef6ff;max-width:760px;margin:40px auto;padding:0 18px}h1{color:#68e1ff}section{background:#1b2a40;padding:20px;border-radius:14px;margin:16px 0}.status{font-weight:800;font-size:20px}.muted{color:#aebed0}button,a.btn{display:inline-block;padding:11px 16px;border:0;border-radius:8px;background:#1389bd;color:white;font-weight:700;text-decoration:none;margin:5px 6px 5px 0;cursor:pointer}button.stop{background:#a83d4b}code{background:#0b1320;padding:3px 6px;border-radius:5px}#error{color:#ff9b9b;white-space:pre-wrap}</style><h1>Country Battle — Mobile Control</h1><section><div id="state" class="status">Checking bridge…</div><p id="detail" class="muted">Loading status</p><p id="error"></p><button onclick="connect()">CONNECT TO YOUTUBE LIVE</button><button class="stop" onclick="disconnect()">DISCONNECT</button></section><section><h3>1. Authorize your YouTube channel</h3><p>Use the Google account that owns or manages the live broadcast.</p><a class="btn" href="/auth/google">AUTHORIZE WITH GOOGLE</a></section><section><h3>2. Open the game</h3><p><a class="btn" href="/game">OPEN COUNTRY BATTLE GAME</a></p><p>The game is served by this same mobile server. Its bridge address is already set to localhost.</p><p class="muted">Bridge API: <code>/api/status</code> • Game event stream: <code>/events</code></p></section><script>async function refresh(){try{const r=await fetch('/api/status');const s=await r.json();const el=document.getElementById('state');el.textContent=s.state==='CONNECTED'?'CONNECTED':s.state==='ERROR'?'ERROR':'DISCONNECTED';el.style.color=s.state==='CONNECTED'?'#75f0aa':s.state==='ERROR'?'#ff8585':'#ffd36b';document.getElementById('detail').textContent=(s.authenticated?'Google account authorized. ':'Google account not authorized. ')+(s.broadcastTitle?'Broadcast: '+s.broadcastTitle+'. ':'')+'Game listeners: '+s.viewers+'.';document.getElementById('error').textContent=s.error||''}catch(e){document.getElementById('state').textContent='ERROR';document.getElementById('error').textContent=e.message}}async function connect(){try{const r=await fetch('/api/connect',{method:'POST'});const d=await r.json();if(!r.ok)throw Error(d.error||'Could not connect');}catch(e){document.getElementById('error').textContent=e.message}refresh()}async function disconnect(){try{await fetch('/api/disconnect',{method:'POST'})}catch(e){}refresh()}refresh();setInterval(refresh,2500);</script></html>`));
// Native navigation destinations. OAuth secrets are deliberately not collected by an
// ordinary WebView form: the current Web OAuth client requires a confidential server-side
// secret and this APK does not yet provide a Keystore-backed credential hand-off.
app.get("/settings", (_req, res) => res.type("html").send(`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Google / YouTube Settings</title><style>body{font:16px system-ui;background:#08152c;color:#effaff;padding:22px}section{max-width:680px;margin:auto;background:#142747;padding:20px;border-radius:14px}h2{color:#64f6ff}a,button{display:inline-block;padding:12px 16px;border-radius:9px;background:#087fc2;color:white;text-decoration:none;border:0;font-weight:700}small{color:#aebed0;line-height:1.6}</style><section><h2>Google / YouTube Settings</h2><p>Google authorization is handled by the local Node bridge.</p><p><b>Current project configuration:</b> OAuth Client ID, Client Secret and redirect URI are read from the bridge's private runtime environment.</p><p><small>Security note: a Web Application Client Secret must not be stored in ordinary WebView storage or packaged in the APK. This project does not yet include a secure Android Keystore credential hand-off or a server-side OAuth broker, so credentials cannot safely be saved from this screen.</small></p><a href="/auth/google">AUTHORIZE WITH GOOGLE</a><p><small>Expected callback: http://localhost:8787/auth/callback</small></p></section>`));
app.get("/status", (_req, res) => res.type("html").send(`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Connection Status</title><style>body{font:16px system-ui;background:#08152c;color:#effaff;padding:22px}main{max-width:680px;margin:auto;background:#142747;padding:20px;border-radius:14px}h2{color:#64f6ff}#state{font-size:28px;font-weight:800}button{padding:12px;border:0;border-radius:8px;background:#087fc2;color:white;font-weight:700}</style><main><h2>Connection Status</h2><div id="state">Checking…</div><p id="detail"></p><button onclick="fetch('/api/connect',{method:'POST'}).then(refresh)">CONNECT</button> <button onclick="fetch('/api/disconnect',{method:'POST'}).then(refresh)">DISCONNECT</button></main><script>async function refresh(){try{let s=await(await fetch('/api/status')).json();let e=document.getElementById('state');e.textContent=s.connected?'CONNECTED':s.state;e.style.color=s.connected?'#30ee65':'#ffd879';document.getElementById('detail').textContent=(s.authenticated?'Google authorized. ':'Google not authorized. ')+(s.error||'')}catch(e){document.getElementById('state').textContent='DISCONNECTED'}}refresh();setInterval(refresh,2500)</script>`));
app.get("/about", (_req, res) => res.type("html").send(`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>About Country Battle</title><style>body{font:16px system-ui;background:#08152c;color:#effaff;padding:22px}main{max-width:680px;margin:auto;background:#142747;padding:20px;border-radius:14px}h2{color:#64f6ff}</style><main><h2>COUNTRY BATTLE</h2><p>Mobile Country Battle game with the embedded local YouTube Live Chat bridge.</p><p>Package: com.countrybattle.mobile</p><p>Architecture: ARM64 (arm64-v8a)</p><p>Bridge callback: http://localhost:8787/auth/callback</p></main>`));
// Serve the complete game from the same local server so Android Chrome uses one origin.
app.get("/game", (_req, res) => res.sendFile(path.join(__dirname, "game", "index.html")));
app.get("/health", (_req, res) => res.json({ ok: true, ...statusPayload() }));
app.get("/api/status", (_req, res) => res.json(statusPayload()));
app.get("/events", (req, res) => {
  res.status(200);
  res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders?.();
  res.write(`data: ${JSON.stringify(statusPayload())}\n\n`);
  clients.add(res);
  const heartbeat = setInterval(() => { try { res.write(": keep-alive\n\n"); } catch { clearInterval(heartbeat); clients.delete(res); } }, 20000);
  req.on("close", () => { clearInterval(heartbeat); clients.delete(res); });
});
app.get("/auth/google", (_req, res) => {
  if (!CLIENT_ID || !CLIENT_SECRET) return res.status(500).send("Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in .env first, then restart the bridge.");
  const stateToken = crypto.randomBytes(32).toString("hex");
  oauthStates.set(stateToken, Date.now());
  for (const [key, created] of oauthStates) if (Date.now() - created > 10 * 60 * 1000) oauthStates.delete(key);
  const url = oauth2.generateAuthUrl({ access_type: "offline", prompt: "consent", include_granted_scopes: true, scope: SCOPES, state: stateToken });
  res.redirect(url);
});
app.get("/auth/callback", async (req, res) => {
  try {
    if (req.query.error) return res.status(400).send(`Google authorization was not completed: ${String(req.query.error)}`);
    const stateToken = String(req.query.state || "");
    const created = oauthStates.get(stateToken);
    if (!created || Date.now() - created > 10 * 60 * 1000) return res.status(400).send("OAuth state check failed or expired. Please retry from /auth/google.");
    oauthStates.delete(stateToken);
    const code = String(req.query.code || "");
    if (!code) return res.status(400).send("Google did not return an authorization code.");
    const { tokens } = await oauth2.getToken(code);
    oauth2.setCredentials({ ...(oauth2.credentials || {}), ...tokens });
    saveTokens({ ...(oauth2.credentials || {}), ...tokens });
    setState("DISCONNECTED", "YouTube account authorized. Start your live stream with chat enabled, then click CONNECT TO YOUTUBE LIVE.");
    res.type("html").send("<!doctype html><meta charset=utf-8><title>Authorization complete</title><h2>YouTube authorization saved.</h2><p>Return to <a href=\"/\">the bridge dashboard</a> and click CONNECT TO YOUTUBE LIVE.</p>");
  } catch (e) {
    const info = getApiError(e);
    setState("ERROR", `OAuth failed: ${info.message}`);
    res.status(500).send(`YouTube authorization failed: ${info.message}`);
  }
});
app.post("/api/connect", async (_req, res) => {
  connectRequested = true;
  if (!isAuthenticated()) {
    setState("ERROR", "Authorize your YouTube account first at /auth/google.");
    return res.status(401).json({ ok: false, error: lastError, ...statusPayload() });
  }
  if (state === "CONNECTED" || state === "CONNECTING") return res.json({ ok: true, ...statusPayload() });
  if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
  try {
    await discoverAndConnect(false);
    if (state === "ERROR") return res.status(500).json({ ok: false, error: lastError, ...statusPayload() });
    return res.json({ ok: true, ...statusPayload() });
  } catch (e) {
    const info = getApiError(e);
    setState("ERROR", info.message);
    return res.status(500).json({ ok: false, error: info.message, ...statusPayload() });
  }
});
app.post("/api/disconnect", (_req, res) => {
  connectRequested = false;
  stopConnection(true);
  setState("DISCONNECTED", "Disconnected by user.");
  res.json({ ok: true, ...statusPayload() });
});

const server = app.listen(PORT, HOST, () => {
  try { fs.writeFileSync(path.join(__dirname, "bridge.pid"), String(process.pid)); } catch {}
  console.log(`Country Battle YouTube Live Chat Bridge listening at http://${HOST}:${PORT}`);
  console.log(`Mobile dashboard: http://localhost:${PORT}`);
  console.log(`Game: http://localhost:${PORT}/game`);
  if (!CLIENT_ID || !CLIENT_SECRET) console.warn("OAuth credentials not configured. Copy .env.example to .env and add your Google OAuth Client ID/Secret.");
  else if (isAuthenticated()) {
    console.log("Saved YouTube authorization found. Automatically checking for an active live chat.");
    connectRequested = true;
    setTimeout(() => discoverAndConnect(false), 1200);
  }
});
server.on("error", e => { console.error(`Could not start bridge on ${HOST}:${PORT}: ${e.message}`); process.exitCode = 1; });
function shutdown() {
  connectRequested = false;
  stopConnection(true);
  for (const res of clients) { try { res.end(); } catch {} }
  try { fs.unlinkSync(path.join(__dirname, "bridge.pid")); } catch {}
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 2500).unref();
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
